# Rules Repository (Living Document)

This document tracks the completeness and consistency rules we identify as we work
through each artifact type. Rules are grouped by artifact type (Use Case, Data Model,
etc.) and tagged by category. This is meant to grow incrementally — new rules get
appended as they surface, not designed all at once.

**Categories:**
- **Completeness** — a required element is present / filled in.
- **Consistency (Referential)** — a symbolic reference (ID, name) used in one place
  resolves to a real, defined entry elsewhere.
- **Consistency (Semantic)** — terms/concepts are used the same way across artifacts
  (not yet started — will matter once we compare use cases to the domain model/glossary).

**Status:**
- **Confirmed** — agreed and ready to implement in tooling.
- **Open** — identified but not yet fully resolved/agreed.

---

## Use Case Rules

| ID | Category | Rule | Notes | Status |
|---|---|---|---|---|
| UC-001 | Consistency (Referential) | Every **Included Use Case** reference (`<<include>>`) resolves to a real Use Case ID in the model. | | Confirmed |
| UC-002 | Consistency (Referential) | Every **Extends / Extended By** reference (`<<extend>>`) resolves to a real Use Case ID in the model. | Extend field also carries an extension point (step/condition); that condition should reference a real step in the base use case's flows once we formalize the field. | Confirmed |
| UC-003 | Consistency (Referential) | Every exception reference (`E#`) used in a Basic Flow, Alternate Path, or Exception Paths table resolves to a real entry in the centralized **Exception Registry**. | Exceptions are centrally defined and reusable across use cases, same pattern as Business Rules. | Confirmed |
| UC-004 | Consistency (Referential) | Every Business Rule reference (`BR#`) resolves to a real entry in the centralized **Business Rules Repository**. | Use case's own Business Rules table becomes a reference list (BR ID + Name), not a redefinition. | Confirmed |
| UC-005 | Consistency (Referential) | Every **Use Case Package** value resolves to an entry in a defined **Package Registry**. | Package registry/list still to be established; packages should reflect business capability, not architecture. | Confirmed |

## Data Model Rules

*(To be populated once we review the ERDs, DFDs, and state transition diagrams.)*

---

## Open Methodological Questions (not yet rules, but tracked for later)

- Is there a distinct "transitional/elaboration" layer between analysis and design
  models for things that don't cleanly belong to either (e.g., non-1:1 use-case-to-
  component mappings)? Raised during use case template review; deferred.
- How do Alternate Paths record where they branch from and (if applicable) rejoin
  the Basic Flow? Deferred pending more real examples.
