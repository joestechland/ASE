# Requirements-to-Code Methodology Project

Living repository for a repeatable methodology (steps, deliverables, tools, techniques,
AI agents) for transforming application requirements into architecture, detailed
design, and executable code — developed alongside a real Web/Mobile app used as a
proof-of-concept case study.

## Structure

```
docs/            High-level methodology documents (lifecycle skeleton, ADRs later)
rules/           Living rules repository — completeness & consistency rules per
                 artifact type (use case rules, data model rules, etc.)
use-cases/
  templates/     Blank use case template(s)
  examples/      Filled-out real use cases (populate as we work through them)
registries/      Centralized reference registries (business rules, exceptions,
                 packages) that use cases and other artifacts point to by ID
```

## Status

Early-stage. Currently working through the use case template and conventions before
moving to real examples, then design mapping. See `docs/lifecycle-skeleton-v0.1.md`
for the overall (deliberately high-level, not-yet-finalized) lifecycle framing, and
`rules/rules-repository.md` for rules identified so far.

## Working conventions

- New rules get appended to `rules/rules-repository.md` as they're identified, not
  designed up front.
- Anything referenced by ID from a use case (Business Rule, Exception, Package,
  another Use Case) should have a single defining entry in `registries/`, not be
  redefined inline.
