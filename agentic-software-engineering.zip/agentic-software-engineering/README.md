# Agentic Software Engineering

Living repository for a repeatable methodology (steps, deliverables, tools,
techniques, AI agents) for transforming application requirements into architecture,
detailed design, and executable code. This project holds the reusable methodology
itself — application-specific work (currently: Hyperlogue) lives in its own separate
project.

## Structure

```
docs/            High-level methodology documents: lifecycle skeleton, the Claude
                 Project instructions used to configure a colleague's Claude the
                 same way, the analysis-activities list
rules/           Living rules repository — completeness & consistency rules per
                 artifact type (Use Case Rules: UCR-xxx, Data Model Rules: DMR-xxx)
use-cases/
  templates/     Blank use case template(s)
open-issues.md   Generic/methodological open issues (OI-xxx)
todo.md          Methodology-level to-do list
```

## Status

Early-stage. Use case template conventions largely settled (see `rules/`); Data
Model conceptual/logical boundary partially settled (DMR-001, DMR-002); Business
Rules and Exception Registry structures still undesigned (OI-005, OI-006).

## Relationship to application projects

This project is meant to be applied to real applications as proof-of-concept case
studies. The first is Hyperlogue (see the `hyperlogue-application` project). When a
methodology question surfaces during application work, it gets logged here as a
generic `OI-###`; application-specific findings (entities, use case content issues)
stay in the application's own project.

## Working conventions

- New rules get appended to `rules/rules-repository.md` as they're identified, not
  designed up front.
- Anything referenced by ID from a use case (Business Rule, Exception, Package,
  another Use Case) should have a single defining entry in a registry, not be
  redefined inline. (Registries themselves are application-specific — see the
  relevant application project.)
