# To-Do List — Agentic Software Engineering (Methodology)

Methodology-level decisions only. Hyperlogue-specific tasks live in that project's
own `todo.md`.

## Waiting on Joe

- [ ] Decide: edit the `.dotx` template now to add the Extends/Extended-By field, or hold
      → OI-001 in `open-issues.md`
- [ ] Design Business Rules Repository structure (ID, Name, Description, Category, Source?)
      → OI-005
- [ ] Design Exception Registry structure → OI-006
- [ ] Confirm whether a dedicated DFD reference source is still coming, or the data
      modeling decks' light DFD coverage is all we're working from → OI-010
- [ ] Decide where data type assignment happens (Logical vs. later/Physical) → DMR-002
      in `rules/rules-repository.md`
- [ ] Confirm CRUDA/CRUN matrix timing: strictly post-hoc, or some interleaving while
      writing a use case? (never explicitly confirmed, currently assumed post-hoc)
- [ ] Set up the actual git repo(s) for both projects — decided in principle, not yet
      done → OI-007

## Waiting on Zach

- [ ] Nothing pending right now — everything outstanding is a decision for Joe

## Conventions

- Summary index only — resolve the underlying tracker item, then check the box here.
