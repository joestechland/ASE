# Open Issues — Hyperlogue Application

Issues specific to the Hyperlogue application. Generic/methodological issues live in
the `agentic-software-engineering` project instead.

| ID | Description | Raised During | Status |
|---|---|---|---|
| OI-003 | No Package Registry existed at the start of this project. Naming convention: "business capability, not architecture" (a generic rule — see UCR-005 in the methodology project). **Resolved (seeded):** registry created at `registries/package-registry.md`, first entry "Manage Hyperlogue" from UC-001. Stays Open in the sense that governance beyond the first entry (e.g., who can add a package, how near-duplicates get caught) hasn't been defined. | Use Case template review; seeded by Create a Hyperlogue package assignment | Open (seeded) |
| OI-011 | Field/attribute definitions embedded in "Create a Hyperlogue" (Title, Description, Participation min/max, token fields, etc., using `*`/`o` notation) confirmed to belong to a **HYPERLOGUE entity**, not the use case itself. The entity hasn't been formally defined by this project (Vasily owns the actual ERD). **Path forward:** these become the first entries in a running entity/attribute list, rather than waiting for a fully-built ERD. Extraction itself not yet performed. | Create a Hyperlogue review / data modeling deck review | Open |

## Conventions for this list

- Use-case-specific items use `OI:UC-xxx-##` and live in that use case's own tracker
  file (e.g. `use-cases/examples/UC-001-issues.md`), not here — this file is for
  application-wide issues that aren't specific to one use case.
- When an item is resolved, don't delete the row — mark it **Resolved** and note where
  the resolution lives.
