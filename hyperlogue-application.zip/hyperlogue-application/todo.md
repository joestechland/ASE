# To-Do List — Hyperlogue Application

Hyperlogue-specific tasks only. Methodology decisions live in the
`agentic-software-engineering` project's own `todo.md`.

## Waiting on Joe

- [ ] Reload revised UC-001 once the current data-model cleanup pass is done
- [ ] Raise PDM-001 through PDM-004 with Vasily → `data-model/pending-changes.md`
- [ ] Upload all repo files to GitHub and share access/orientation with Vasily —
      where things live and how to find them (see `README.md` for the folder map)
- [ ] UC-001 header fields still blank: Version, Author, Priority
      → OI:UC-001-01/02/03 in `use-cases/examples/UC-001-issues.md`
- [ ] UC-001 content: does the included use case ("Fill out HL details w/o
      publishing") exist yet with an ID? → OI:UC-001-04
- [ ] UC-001: confirm Business Rules table Name/Description gaps against the real
      source doc (may just be a PDF-extraction artifact) → OI:UC-001-07
- [ ] UC-001: where the line sits between a Business Rule and a plain data constraint
      → OI:UC-001-08
- [ ] UC-001: confirm "Maximum Number of Matches" ↔ "number of evaluations per
      participant" are the same field → OI:UC-001-11
- [ ] UC-001: confirm Initiator Token Contribution's tie to BR4 → OI:UC-001-14
- [ ] Answer the three UC-001 dev notes (type-of-HL read-only behavior, submission size
      limits, inline linked-content display) → OI:UC-001-18/19/20

## Waiting on Zach

- [ ] Review the revised UC-001, once uploaded, against the current tracker
      (`use-cases/examples/UC-001-issues.md`)

## Conventions

- Summary index only — resolve the underlying tracker item, then check the box here.
