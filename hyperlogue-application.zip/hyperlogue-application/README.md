# Hyperlogue Application

Use cases, data model coordination, and application-specific documentation for the
Hyperlogue application — the proof-of-concept case study for the methodology being
developed in the separate `agentic-software-engineering` project. That project owns
the reusable rules, templates, and conventions this one applies.

## Structure

```
use-cases/
  examples/          Real use cases and their per-use-case issue trackers
                      (e.g. UC-001-issues.md for "Create a Hyperlogue")
data-model/
  pending-changes.md Changes identified during use case work that need to be raised
                      with Vasily (owns the actual ERD) — a request queue, not a
                      registry. Should converge toward empty over the project's life.
registries/
  package-registry.md  Controlled list of Use Case Packages for this application
open-issues.md       Application-specific open issues (OI-xxx, plus OI:UC-xxx-##
                      cross-references into use case trackers)
todo.md              Hyperlogue-specific to-do list
```

## Status

UC-001 ("Create a Hyperlogue") is the first use case under review — 20 issues logged,
several resolved via cross-check against Vasily's ERD screenshot, several more queued
as pending data model change requests (PDM-001–004).

## People

- **Vasily** — owns and maintains the actual Hyperlogue data model (ERD). Changes
  this project identifies get proposed to him via `data-model/pending-changes.md`,
  never applied unilaterally.

## Working conventions

Inherited from `agentic-software-engineering` — see that project's
`docs/claude-project-instructions.md` for the full working relationship (role,
demeanor, process discipline). This project applies those conventions; it doesn't
redefine them.
